
# Consider dependencies only in project.
set(CMAKE_DEPENDS_IN_PROJECT_ONLY OFF)

# The set of languages for which implicit dependencies are needed:
set(CMAKE_DEPENDS_LANGUAGES
  "ASM"
  )
# The set of files for implicit dependencies of each language:
set(CMAKE_DEPENDS_CHECK_ASM
  "D:/STM32/tim2_pwm_breath/Core/Startup/startup_stm32f103c8tx.s" "D:/STM32/tim2_pwm_breath/cmake-build-debug/CMakeFiles/tim2_pwm_breath.elf.dir/Core/Startup/startup_stm32f103c8tx.s.obj"
  )
set(CMAKE_ASM_COMPILER_ID "GNU")

# Preprocessor definitions for this target.
set(CMAKE_TARGET_DEFINITIONS_ASM
  "DEBUG"
  "STM32F103xB"
  "USE_HAL_DRIVER"
  )

# The include file search paths:
set(CMAKE_ASM_TARGET_INCLUDE_PATH
  "D:/STM32/tim2_pwm_breath/Core/Inc"
  "D:/STM32/tim2_pwm_breath/Drivers/STM32F1xx_HAL_Driver/Inc"
  "D:/STM32/tim2_pwm_breath/Drivers/STM32F1xx_HAL_Driver/Inc/Legacy"
  "D:/STM32/tim2_pwm_breath/Drivers/CMSIS/Device/ST/STM32F1xx/Include"
  "D:/STM32/tim2_pwm_breath/Drivers/CMSIS/Include"
  )

# The set of dependency files which are needed:
set(CMAKE_DEPENDS_DEPENDENCY_FILES
  "D:/STM32/tim2_pwm_breath/Core/Src/main.c" "CMakeFiles/tim2_pwm_breath.elf.dir/Core/Src/main.c.obj" "gcc" "CMakeFiles/tim2_pwm_breath.elf.dir/Core/Src/main.c.obj.d"
  "D:/STM32/tim2_pwm_breath/Core/Src/stm32f1xx_hal_msp.c" "CMakeFiles/tim2_pwm_breath.elf.dir/Core/Src/stm32f1xx_hal_msp.c.obj" "gcc" "CMakeFiles/tim2_pwm_breath.elf.dir/Core/Src/stm32f1xx_hal_msp.c.obj.d"
  "D:/STM32/tim2_pwm_breath/Core/Src/stm32f1xx_it.c" "CMakeFiles/tim2_pwm_breath.elf.dir/Core/Src/stm32f1xx_it.c.obj" "gcc" "CMakeFiles/tim2_pwm_breath.elf.dir/Core/Src/stm32f1xx_it.c.obj.d"
  "D:/STM32/tim2_pwm_breath/Core/Src/syscalls.c" "CMakeFiles/tim2_pwm_breath.elf.dir/Core/Src/syscalls.c.obj" "gcc" "CMakeFiles/tim2_pwm_breath.elf.dir/Core/Src/syscalls.c.obj.d"
  "D:/STM32/tim2_pwm_breath/Core/Src/sysmem.c" "CMakeFiles/tim2_pwm_breath.elf.dir/Core/Src/sysmem.c.obj" "gcc" "CMakeFiles/tim2_pwm_breath.elf.dir/Core/Src/sysmem.c.obj.d"
  "D:/STM32/tim2_pwm_breath/Core/Src/system_stm32f1xx.c" "CMakeFiles/tim2_pwm_breath.elf.dir/Core/Src/system_stm32f1xx.c.obj" "gcc" "CMakeFiles/tim2_pwm_breath.elf.dir/Core/Src/system_stm32f1xx.c.obj.d"
  "D:/STM32/tim2_pwm_breath/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal.c" "CMakeFiles/tim2_pwm_breath.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal.c.obj" "gcc" "CMakeFiles/tim2_pwm_breath.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal.c.obj.d"
  "D:/STM32/tim2_pwm_breath/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_cortex.c" "CMakeFiles/tim2_pwm_breath.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_cortex.c.obj" "gcc" "CMakeFiles/tim2_pwm_breath.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_cortex.c.obj.d"
  "D:/STM32/tim2_pwm_breath/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_dma.c" "CMakeFiles/tim2_pwm_breath.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_dma.c.obj" "gcc" "CMakeFiles/tim2_pwm_breath.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_dma.c.obj.d"
  "D:/STM32/tim2_pwm_breath/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_exti.c" "CMakeFiles/tim2_pwm_breath.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_exti.c.obj" "gcc" "CMakeFiles/tim2_pwm_breath.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_exti.c.obj.d"
  "D:/STM32/tim2_pwm_breath/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_flash.c" "CMakeFiles/tim2_pwm_breath.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_flash.c.obj" "gcc" "CMakeFiles/tim2_pwm_breath.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_flash.c.obj.d"
  "D:/STM32/tim2_pwm_breath/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_flash_ex.c" "CMakeFiles/tim2_pwm_breath.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_flash_ex.c.obj" "gcc" "CMakeFiles/tim2_pwm_breath.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_flash_ex.c.obj.d"
  "D:/STM32/tim2_pwm_breath/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_gpio.c" "CMakeFiles/tim2_pwm_breath.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_gpio.c.obj" "gcc" "CMakeFiles/tim2_pwm_breath.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_gpio.c.obj.d"
  "D:/STM32/tim2_pwm_breath/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_gpio_ex.c" "CMakeFiles/tim2_pwm_breath.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_gpio_ex.c.obj" "gcc" "CMakeFiles/tim2_pwm_breath.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_gpio_ex.c.obj.d"
  "D:/STM32/tim2_pwm_breath/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_pwr.c" "CMakeFiles/tim2_pwm_breath.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_pwr.c.obj" "gcc" "CMakeFiles/tim2_pwm_breath.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_pwr.c.obj.d"
  "D:/STM32/tim2_pwm_breath/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_rcc.c" "CMakeFiles/tim2_pwm_breath.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_rcc.c.obj" "gcc" "CMakeFiles/tim2_pwm_breath.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_rcc.c.obj.d"
  "D:/STM32/tim2_pwm_breath/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_rcc_ex.c" "CMakeFiles/tim2_pwm_breath.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_rcc_ex.c.obj" "gcc" "CMakeFiles/tim2_pwm_breath.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_rcc_ex.c.obj.d"
  "D:/STM32/tim2_pwm_breath/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_tim.c" "CMakeFiles/tim2_pwm_breath.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_tim.c.obj" "gcc" "CMakeFiles/tim2_pwm_breath.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_tim.c.obj.d"
  "D:/STM32/tim2_pwm_breath/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_tim_ex.c" "CMakeFiles/tim2_pwm_breath.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_tim_ex.c.obj" "gcc" "CMakeFiles/tim2_pwm_breath.elf.dir/Drivers/STM32F1xx_HAL_Driver/Src/stm32f1xx_hal_tim_ex.c.obj.d"
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_LINKED_INFO_FILES
  )

# Targets to which this target links which contain Fortran sources.
set(CMAKE_Fortran_TARGET_FORWARD_LINKED_INFO_FILES
  )

# Fortran module output directory.
set(CMAKE_Fortran_TARGET_MODULE_DIR "")
