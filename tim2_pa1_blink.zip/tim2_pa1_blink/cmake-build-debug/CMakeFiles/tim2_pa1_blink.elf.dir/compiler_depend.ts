# CMAKE generated file: DO NOT EDIT!
# Timestamp file for compiler generated dependencies management for tim2_pa1_blink.elf.
